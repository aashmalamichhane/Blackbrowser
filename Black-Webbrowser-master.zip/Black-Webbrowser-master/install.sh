# Black-Webbrowser Installing
#

echo "Installing..."
echo ""

sudo apt install python
sudo apt install python3

pip install PyQt5
pip install -r requirements.txt


echo "Finish...!"
echo "Use: python black.py"

exit
